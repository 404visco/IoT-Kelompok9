def D(x,y,z):
     return y*y-4*x*z
def x1(x,y,z):
    return ((-y)+D(x,y,z)**0.5)/2*x
def x2(x,y,z):
    return ((-y)-D(x,y,z)**0.5)/2*x
def absol(x):
    if x>= 0:
        return x
    else:
        return x*-1
def Aljabar(x,y,z):
    if absol(x1(x,y,z))>=absol(x2(x,y,z)):
        return round(absol(x2(x,y,z))/absol(x1(x,y,z)),5)
    else:
        return round(absol(x1(x,y,z))/absol(x2(x,y,z)),5)

print(Aljabar(1,-5, 6))
# Nama File: bawapayung.py
# Nama / NIM: Visco Argatha Tawa Tawa / 24060125120023
# Tanggal: 16 September 2025

def BawaPayung(suhu,prob):
    if suhu>35 or prob>=50:
        return 'Bawa'
    else:
        return 'Tidak bawa'

#JANGAN DIUBAH!
print(eval(input()))
# Nama File: bagiapel.py
# Nama / NIM: Visco Argatha Tawa Tawa / 24060125120023
# Tanggal: 16 September 2025

def bagiApel(x):
    if x%2==0 and x>2:
        return 'Bisa'
    else:
        return 'Tidak'

#JANGAN DIUBAH!
print(eval(input()))

# Nama File: aljabar.py
# Nama / NIM: Visco Argatha Tawa Tawa / 24060125120023
# Tanggal: 16 September 2025

def D(x,y,z):
     return y*y-4*x*z
def x1(x,y,z):
    return ((-y)+D(x,y,z)**0.5)/2*x
def x2(x,y,z):
    return ((-y)-D(x,y,z)**0.5)/2*x
def absol(x):
    if x>= 0:
        return x
    else:
        return x*-1
def Aljabar(x,y,z):
    if D(x,y,z)<0:
        return -999
    elif absol(x1(x,y,z))>=absol(x2(x,y,z)):
        return round(absol(x2(x,y,z))/absol(x1(x,y,z)),5)
    else:
        return round(absol(x1(x,y,z))/absol(x2(x,y,z)),5)

#JANGAN DIUBAH!
print(eval(input()))

# Nama File: aljabar.py
# Nama / NIM: Farrelino Arvia Atmajaya / 24060125120033
# Tanggal: 16 September 2025

def min2(x, y):
    return x if x <= y else y

def maks2(x, y):
    return x if x >= y else y

def diskriminan(a, b, c):
    return (b*b) - (4*a*c)

def x1(a, b, c):
    return (-b + (diskriminan(a, b, c)**0.5)) / (2*a)

def x2(a, b, c):
    return (-b - (diskriminan(a, b, c)**0.5)) / (2*a)

def absolute(x):
    return x if x >= 0 else -x

def Aljabar(a, b, c):
    if (a == 0):
        return -999.0
    if (diskriminan(a, b, c) >= 0):
        if maks2(absolute(x1(a, b, c)), absolute(x2(a,b,c))) == 0:
            return -999.0
        return round(min2(absolute(x1(a, b, c)), absolute(x2(a,b,c))) / maks2(absolute(x1(a, b, c)), absolute(x2(a,b,c))), 5)
    else :
        return -999.0