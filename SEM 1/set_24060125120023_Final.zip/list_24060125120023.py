def FirstElmt(L):
    return L[0]
def LastElmt(L):
    return L[-1]
def Konso(E,L):
    return [E]+L
def Konsi(L,E):
    return L+[E]
def Head(L):
    return L[:-1]
def Tail(L):
    return L[1:]
def IsKosong(L):
    return L == []
def BanyakElmt(L):
    if IsKosong(L):
        return 0
    else:
        return 1+BanyakElmt(Tail(L))


#TUGAS
def ElmtKeN(N,L):
    if N==1:
        return FirstElmt(L)
    else:
        return ElmtKeN(N-1, Tail(L))
# print('=== ELEMENT KE N ===')
# print(ElmtKeN(3,[1,2,3]))

def IsMember(N,L):
    if L==[]:
        return False
    elif N== FirstElmt(L):
        return True
    else:
        return IsMember(N,Tail(L))
# print('=== IsMEMBER ===')
# print(IsMember(5,[1,2,3]))